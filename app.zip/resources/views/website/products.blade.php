@extends('layouts.test')
@section('css')
    
@endsection

@section('content')
    <h1>welcome to product page</h1>
    <img src="{{url("storage/logoipsum-297 (2).svg")}}" alt="testing logo">
    <img src="{{asset("storage/logoipsum-297 (2).svg")}}" alt="testing logo">
@endsection