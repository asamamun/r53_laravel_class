@extends('layouts.test')
@section('css')
    
@endsection

@section('content')
    <h1>welcome to service page</h1>
@endsection